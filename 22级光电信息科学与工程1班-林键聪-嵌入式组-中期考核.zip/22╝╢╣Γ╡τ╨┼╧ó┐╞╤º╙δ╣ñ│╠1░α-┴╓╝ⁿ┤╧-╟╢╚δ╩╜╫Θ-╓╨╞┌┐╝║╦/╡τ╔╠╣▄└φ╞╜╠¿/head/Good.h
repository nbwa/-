#ifndef GOOD_H
#define GOOD_H
#include"Linklist.h"

void Good_NewIn(GoodN* GH,UserN* UH);
void Good_Numin(GoodN* GH,UserN* UH);
void Good_Search(GoodN* UH);
void Good_NumSearch(GoodN* GH);

#endif // !GOOD_H

