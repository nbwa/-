#ifndef _EXC_H
#define _EXC_H
#include"Linklist.h"

void Search_Exchange(ExcN* EH);
void User_SearchExc(ExcN* EH, UserN* q);
void Exchange_out(ExcN* EH);

#endif // !_EXC_H
