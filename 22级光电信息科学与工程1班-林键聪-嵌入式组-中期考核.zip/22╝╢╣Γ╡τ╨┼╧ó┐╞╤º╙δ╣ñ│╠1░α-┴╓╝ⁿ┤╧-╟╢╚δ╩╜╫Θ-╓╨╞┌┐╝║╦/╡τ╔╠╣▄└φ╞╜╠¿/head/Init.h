#ifndef  INIT_H
#define INIT_H



int Init3();

#endif //  INIT_H

