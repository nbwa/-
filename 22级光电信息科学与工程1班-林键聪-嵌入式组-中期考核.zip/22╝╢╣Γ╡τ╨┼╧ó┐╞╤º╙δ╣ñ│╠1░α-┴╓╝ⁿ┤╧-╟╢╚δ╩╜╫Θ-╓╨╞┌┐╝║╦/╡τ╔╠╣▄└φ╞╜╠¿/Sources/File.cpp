#define _CRT_SECURE_NO_WARNINGS
#include"File.h"
#include <stdio.h>
#include "stdlib.h"
#include <string.h>


//��User�ı����ݴ���������
void ReadUserFile(UserN* UH)
{
	char name[11];
	char password[11];
	int id;
	char phone[21];
	double money;
	FILE* p;
	
	fopen_s(&p,"User.txt", "r");
	if (p == NULL)
	{
		printf("���ļ�ʧ��\n");
		exit(0);
	}
	UserN* q = UH;

	if ((fscanf(p, "%d %s %s %lf %s \n", &id, name, password, &money, phone)) != EOF)
	{
		UH->id = id;
		UH->money = money;
		strcpy_s(UH->name, name);
		strcpy_s(UH->password, password);
		strcpy_s(UH->phone, phone);
	}
	while ((fscanf(p,"%d %s %s %lf %s \n",&id,name,password,&money,phone))!=EOF) //���ı�����д����
	{
		UserN* X= (UserN*)malloc(sizeof(UserN));
		X->next = q->next;
		q->next = X;
		q = q->next;
		X->id = id;
		X->money = money;
		strcpy_s(X->name, name);
		strcpy_s(X->password, password);
		strcpy_s(X->phone, phone);
	}
	fclose(p);
	        
}

void ReadGoodFile(GoodN* GH)
{
	int id;
	int num;
	char name[11] ;
	double price;
	FILE* p;

	fopen_s(&p, "Good.txt", "r");
	if (p == NULL)
	{
		printf("���ļ�ʧ��\n");
		exit(0);
	}
	GoodN* q = GH;

	while ((fscanf(p, "%d %s %d %lf\n", &id, name, &num, &price))!=EOF)
	{
		GoodN* X = (GoodN*)malloc(sizeof(GoodN));
		X->next = q->next;
		q->next = X;
		q = q->next;

		X->id = id;
		X->num = num;
		X->price = price;
		strcpy_s(X->name, name);
	}
	fclose(p);
}


void ReadExcFile(ExcN* EH)
{
	long long int id;
	char name[11];
	char goodname[16];
	double money;
	int condition;
	FILE* p;

	fopen_s(&p, "Exchange.txt", "r");
	if (p == NULL)
	{
		printf("���ļ�ʧ��\n");
		exit(0);
	}
	ExcN* q = EH;

	while ((fscanf(p, "%lld %s %s %lf %d\n", &id, name, goodname, &money, &condition)) != EOF)
	{
		ExcN* X = (ExcN*)malloc(sizeof(ExcN));
		X->next = q->next;
		q->next = X;
		q = q->next;

		X->id = id;
		X->money = money;
		X->condition = condition;
		strcpy_s(X->name, name);
		strcpy_s(X->goodname, goodname);

	}
	fclose(p);

}


void InallFile(UserN* UH,GoodN* GH,ExcN* EH)
{
	FILE* fp= (FILE*)malloc(sizeof(FILE));   //�����ļ��ռ�
	GoodN* p = GH;
	UserN* q = UH;
	ExcN*  L = EH;

//	��Good��������������ļ���
	 fopen_s(&fp, "Good.txt", "w");
	if (fp==NULL)
	{
		printf("���ļ�ʧ��\n");

		exit(0);
	}
	while (p=p->next)
	{
		fprintf(fp, "%-10d %-20s %-5d %-10.2lf\n", p->id, p->name, p->num, p->price);
	}
	fclose(fp);


//	��User��������������ļ���
	fopen_s(&fp, "User.txt", "w");
	if (fp==NULL)
	{
		printf("���ļ�ʧ��\n");
		exit(0);
	}

	fprintf(fp, "%-5d %-15s %-15s %-15.2lf %-15s\n", q->id, q->name, q->password, q->money, q->phone);
	while (q=q->next)
	{
		fprintf(fp, "%-5d %-15s %-15s %-15.2lf %-15s\n", q->id, q->name, q->password, q->money,q->phone);
	}
	fclose(fp);


// ��Exchange��������������ļ���
	fopen_s(&fp, "Exchange.txt", "w");
	if (fp == NULL)
	{
		printf("���ļ�ʧ��\n");

		exit(0);
	}
	while (L = L->next)
		fprintf(fp, "%-15lld %-15s %-15s %-15lf %-15d\n", L->id, L->name, L->goodname, L->money, L->condition);

	fclose(fp);
}

